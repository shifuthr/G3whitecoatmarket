document.getElementById('closePopup').addEventListener('click', function () {
    document.getElementById('popupAd').style.display = 'none';
});

window.onload = function () {
    setTimeout(function () {
        document.getElementById('popupAd').style.display = 'flex';
    }, 2000);
};
Write to GROUP 3 w/o CI 2nd Sem
